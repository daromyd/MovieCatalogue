package com.example.moviecatalogue.ui.detail.tvshow

import com.example.moviecatalogue.utils.DataDummy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class DetailTvShowViewModelTest {

    private lateinit var viewModel: DetailTvShowViewModel
    private val dummyTvShow = DataDummy.generateDummyTvShows()[0]
    private val tvShowId = dummyTvShow.tvShowId
    private val title = dummyTvShow.title
    private val eps = dummyTvShow.eps

    @Before
    fun setUp(){
        viewModel = DetailTvShowViewModel()
        viewModel.selectedTvShow(tvShowId, title, eps)
    }

    @Test
    fun getTvShow() {
        viewModel.selectedTvShow(dummyTvShow.tvShowId, dummyTvShow.title, dummyTvShow.eps)
        val tvShowEntity = viewModel.getTvShow()
        assertNotNull(tvShowEntity)
        assertEquals(dummyTvShow.tvShowId, tvShowEntity.tvShowId)
        assertEquals(dummyTvShow.title, tvShowEntity.title)
        assertEquals(dummyTvShow.year, tvShowEntity.year)
        assertEquals(dummyTvShow.rating, tvShowEntity.rating)
        assertEquals(dummyTvShow.eps, tvShowEntity.eps)
        assertEquals(dummyTvShow.genre, tvShowEntity.genre)
        assertEquals(dummyTvShow.sinopsis, tvShowEntity.sinopsis)
        assertEquals(dummyTvShow.poster, tvShowEntity.poster)
    }

    @Test
    fun getEpisode() {

        val epsEntities = viewModel.getEpisode()
        assertNotNull(epsEntities)
        assertEquals(eps, epsEntities.size)
    }
}