package com.example.moviecatalogue.data

data class EpisodeEntity(
        var episodeId: String,
        var tvShowId: String,
        var title: String,
        var duration: Int
)
