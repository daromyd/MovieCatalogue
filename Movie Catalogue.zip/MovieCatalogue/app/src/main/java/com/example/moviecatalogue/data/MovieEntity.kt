package com.example.moviecatalogue.data

data class MovieEntity(
    var movieId: String,
    var title: String,
    var year: Int,
    var rating: Float,
    var duration: Int,
    var genre: String,
    var sinopsis: String,
    var poster: String

)
