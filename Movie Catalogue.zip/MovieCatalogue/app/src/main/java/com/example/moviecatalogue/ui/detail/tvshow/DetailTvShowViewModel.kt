package com.example.moviecatalogue.ui.detail.tvshow

import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.data.EpisodeEntity
import com.example.moviecatalogue.data.TvShowEntity
import com.example.moviecatalogue.utils.DataDummy

class DetailTvShowViewModel : ViewModel(){
    private lateinit var tvShowId: String
    private lateinit var title: String
    private var eps = 0


    fun selectedTvShow(tvShowId: String, title:String, eps:Int){
        this.tvShowId = tvShowId
        this.title = title
        this.eps = eps
    }

    fun getTvShow(): TvShowEntity{
        lateinit var tvShow : TvShowEntity
        val tvShowEntities = DataDummy.generateDummyTvShows()
        for (tvShowEntity in tvShowEntities){
            if (tvShowEntity.tvShowId == tvShowId){
                tvShow = tvShowEntity
            }
        }
        return tvShow
    }

    fun getEpisode(): List<EpisodeEntity> = DataDummy.generateDummyEpisodes(tvShowId, title, eps)
}