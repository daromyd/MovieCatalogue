package com.example.moviecatalogue.ui.detail.tvshow

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.moviecatalogue.R
import com.example.moviecatalogue.data.EpisodeEntity
import kotlinx.android.synthetic.main.item_episode_list.view.*

class DetailTvShowAdapter : RecyclerView.Adapter<DetailTvShowAdapter.EpsViewHolder>() {
    private val listEpisodes = ArrayList<EpisodeEntity>()

    fun setEpisodes(episodes: List<EpisodeEntity>?){
        if (episodes == null) return
        this.listEpisodes.clear()
        this.listEpisodes.addAll(episodes)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EpsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_episode_list, parent, false)
        return EpsViewHolder(view)
    }

    override fun onBindViewHolder(holder: EpsViewHolder, position: Int) {
        val episode =  listEpisodes[position]
        holder.bind(episode)
    }

    override fun getItemCount(): Int = listEpisodes.size

    inner class EpsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(episode: EpisodeEntity){
            with(itemView){
                tv_item_episode_title.text = episode.title
                tv_item_duration.text = resources.getString(R.string.duration, episode.duration)
            }
        }

    }

}
