package com.example.moviecatalogue.data

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.moviecatalogue.data.source.remote.RemoteDataSource
import com.example.moviecatalogue.utils.DataDummy
import com.example.moviecatalogue.utils.LiveDataTestUtil
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.doAnswer
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.verify
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito.mock

class MovieCatalogueRepositoryTest{

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private val remote = mock(RemoteDataSource::class.java)
    private val movieCatalogueRepository =  FakeMovieCatalogueRepository(remote)

    private val movieResponse = DataDummy.generateRemoteDummyMovies()
    private val movieId = movieResponse[0].movieId

    private val tvShowResponse = DataDummy.generateRemoteDummyTvShows()
    private val tvShowId = tvShowResponse[0].tvShowId
    private val title = tvShowResponse[0].title
    private val eps = tvShowResponse[0].eps

    private val episodeResponse = DataDummy.generateRemoteDummyEpisodes(tvShowId, title, eps)

    @Test
    fun getAllMovies(){
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteDataSource.LoadMoviesCallback)
                .onAllMoviesReceived(movieResponse)
            null
        }.`when`(remote).getAllMovies(any())
        val movieEntities = LiveDataTestUtil.getValue(movieCatalogueRepository.getAllMovies())
        verify(remote).getAllMovies(any())
        assertNotNull(movieEntities)
        assertEquals(movieResponse.size.toLong(), movieEntities.size.toLong())
    }

    @Test
    fun getAllTvShows(){
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteDataSource.LoadTvShowsCallback)
                .onAllTvShowsReceived(tvShowResponse)
            null
        }.`when`(remote).getAllTvShows(any())
        val tvShowEntities = LiveDataTestUtil.getValue(movieCatalogueRepository.getAllTvShows())
        verify(remote).getAllTvShows(any())
        assertNotNull(tvShowEntities)
        assertEquals(tvShowResponse.size.toLong(), tvShowEntities.size.toLong())
    }

    @Test
    fun getDetailMovie(){
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteDataSource.LoadMoviesCallback)
                .onAllMoviesReceived(movieResponse)
            null
        }.`when`(remote).getAllMovies(any())

        val resultMovie = LiveDataTestUtil.getValue(movieCatalogueRepository.getDetailMovie(movieId))

        verify(remote).getAllMovies(any())

        assertNotNull(resultMovie)
        assertNotNull(resultMovie.title)
        assertEquals(movieResponse[0].title, resultMovie.title)
    }

    @Test
    fun getDetailTvShow(){
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteDataSource.LoadTvShowsCallback)
                .onAllTvShowsReceived(tvShowResponse)
            null
        }.`when`(remote).getAllTvShows(any())

        val resultTvShow = LiveDataTestUtil.getValue(movieCatalogueRepository.getDetailTvShow(tvShowId))

        verify(remote).getAllTvShows(any())

        assertNotNull(resultTvShow)
        assertNotNull(resultTvShow.title)
        assertEquals(tvShowResponse[0].title, resultTvShow.title)
    }

    @Test
    fun getEpisodesByTvShow(){
        doAnswer { invocation ->
            (invocation.arguments[1] as RemoteDataSource.LoadEpisodesCallback)
                .onAllEpisodesReceived(episodeResponse)
            null
        }.`when`(remote).getEpisodes(eq(tvShowId), any())


        val episodeEntities = LiveDataTestUtil.getValue(movieCatalogueRepository.getEpisodesByTvShow(tvShowId))

        verify(remote).getEpisodes(eq(tvShowId), any())
        assertNotNull(episodeEntities)
        assertEquals(episodeResponse.size.toLong(), episodeEntities.size.toLong())
    }
}