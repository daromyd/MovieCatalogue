package com.example.moviecatalogue.ui.detail.tvshow

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.example.moviecatalogue.data.MovieCatalogueRepository
import com.example.moviecatalogue.data.source.local.entity.EpisodeEntity
import com.example.moviecatalogue.data.source.local.entity.TvShowEntity
import com.example.moviecatalogue.utils.DataDummy
import com.nhaarman.mockitokotlin2.verify
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner


@RunWith(MockitoJUnitRunner::class)
class DetailTvShowViewModelTest {

    private lateinit var viewModel: DetailTvShowViewModel
    private val dummyTvShow = DataDummy.generateDummyTvShows()[0]
    private val tvShowId = dummyTvShow.tvShowId
    private val title = dummyTvShow.title
    private val eps = dummyTvShow.eps
    private val dummyEpisode = DataDummy.generateDummyEpisodes(tvShowId, title, eps)

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var movieCatalogueRepository: MovieCatalogueRepository

    @Mock
    private lateinit var tvShowObserver : Observer<TvShowEntity>

    @Mock
    private lateinit var episodeObserver: Observer<List<EpisodeEntity>>

    @Before
    fun setUp(){
        viewModel = DetailTvShowViewModel(movieCatalogueRepository)
        viewModel.selectedTvShow(tvShowId)
    }

    @Test
    fun getTvShow() {
        val tvShow = MutableLiveData<TvShowEntity>()
        tvShow.value = dummyTvShow

        `when`(movieCatalogueRepository.getDetailTvShow(tvShowId)).thenReturn(tvShow)
        val tvShowEntity = viewModel.getTvShow().value as TvShowEntity
        verify(movieCatalogueRepository).getDetailTvShow(tvShowId)
        assertNotNull(tvShowEntity)
        assertEquals(dummyTvShow.tvShowId, tvShowEntity.tvShowId)
        assertEquals(dummyTvShow.title, tvShowEntity.title)
        assertEquals(dummyTvShow.year, tvShowEntity.year)
        assertEquals(dummyTvShow.rating, tvShowEntity.rating)
        assertEquals(dummyTvShow.eps, tvShowEntity.eps)
        assertEquals(dummyTvShow.genre, tvShowEntity.genre)
        assertEquals(dummyTvShow.sinopsis, tvShowEntity.sinopsis)
        assertEquals(dummyTvShow.poster, tvShowEntity.poster)

        viewModel.getTvShow().observeForever(tvShowObserver)
        verify(tvShowObserver).onChanged(dummyTvShow)
    }

    @Test
    fun getEpisode() {
        val episodes = MutableLiveData<List<EpisodeEntity>>()
        episodes.value = dummyEpisode

        `when`(movieCatalogueRepository.getEpisodesByTvShow(tvShowId)).thenReturn(episodes)
        val epsEntities = viewModel.getEpisode().value
        verify(movieCatalogueRepository).getEpisodesByTvShow(tvShowId)
        assertNotNull(epsEntities)
        assertEquals(eps, epsEntities?.size)

        viewModel.getEpisode().observeForever(episodeObserver)
        verify(episodeObserver).onChanged(dummyEpisode)
    }
}