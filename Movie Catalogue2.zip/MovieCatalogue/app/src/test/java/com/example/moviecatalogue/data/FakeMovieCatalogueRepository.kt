package com.example.moviecatalogue.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.moviecatalogue.data.source.local.entity.EpisodeEntity
import com.example.moviecatalogue.data.source.local.entity.MovieEntity
import com.example.moviecatalogue.data.source.local.entity.TvShowEntity
import com.example.moviecatalogue.data.source.remote.RemoteDataSource
import com.example.moviecatalogue.data.source.remote.response.EpisodeResponse
import com.example.moviecatalogue.data.source.remote.response.MovieResponse
import com.example.moviecatalogue.data.source.remote.response.TvShowResponse
import java.util.*

class FakeMovieCatalogueRepository(private val remoteDataSource: RemoteDataSource) : MovieCatalogueDataSource {

    override fun getAllMovies(): LiveData<List<MovieEntity>> {
        val movieResults= MutableLiveData<List<MovieEntity>>()
        remoteDataSource.getAllMovies(object : RemoteDataSource.LoadMoviesCallback {
            override fun onAllMoviesReceived(movieResponse: List<MovieResponse>) {
                val movieList = ArrayList<MovieEntity>()
                for (response in movieResponse){
                    val movie = MovieEntity(
                        response.movieId,
                        response.title,
                        response.year,
                        response.rating,
                        response.duration,
                        response.genre,
                        response.sinopsis,
                        response.poster
                    )
                    movieList.add(movie)
                }
                movieResults.postValue(movieList)
            }

        })
        return movieResults
    }

    override fun getAllTvShows(): LiveData<List<TvShowEntity>> {
        val tvShowResults = MutableLiveData<List<TvShowEntity>>()
        remoteDataSource.getAllTvShows(object : RemoteDataSource.LoadTvShowsCallback {
            override fun onAllTvShowsReceived(tvShowResponse: List<TvShowResponse>) {
                val tvShowList = ArrayList<TvShowEntity>()
                for (response in tvShowResponse){
                    val tvShow = TvShowEntity(
                        response.tvShowId,
                        response.title,
                        response.year,
                        response.rating,
                        response.eps,
                        response.genre,
                        response.sinopsis,
                        response.poster
                    )
                    tvShowList.add(tvShow)
                }
                tvShowResults.postValue(tvShowList)
            }
        })

        return tvShowResults
    }

    override fun getDetailMovie(movieId: String): LiveData<MovieEntity> {
        val movieResult = MutableLiveData<MovieEntity>()
        remoteDataSource.getAllMovies(object : RemoteDataSource.LoadMoviesCallback {
            override fun onAllMoviesReceived(movieResponse: List<MovieResponse>) {
                lateinit var movie: MovieEntity
                for (response in movieResponse){
                    if (response.movieId == movieId){
                        movie = MovieEntity(
                            response.movieId,
                            response.title,
                            response.year,
                            response.rating,
                            response.duration,
                            response.genre,
                            response.sinopsis,
                            response.poster
                        )
                    }
                }
                movieResult.postValue(movie)
            }
        })
        return movieResult
    }

    override fun getDetailTvShow(tvShowId: String): LiveData<TvShowEntity> {
        val tvShowResult = MutableLiveData<TvShowEntity>()
        remoteDataSource.getAllTvShows(object : RemoteDataSource.LoadTvShowsCallback {
            override fun onAllTvShowsReceived(tvShowResponse: List<TvShowResponse>) {
                lateinit var tvShow: TvShowEntity
                for (response in tvShowResponse){
                    if (response.tvShowId == tvShowId){
                        tvShow = TvShowEntity(
                            response.tvShowId,
                            response.title,
                            response.year,
                            response.rating,
                            response.eps,
                            response.genre,
                            response.sinopsis,
                            response.poster
                        )
                    }
                }
                tvShowResult.postValue(tvShow)
            }
        })
        return tvShowResult
    }

    override fun getEpisodesByTvShow(tvShowId: String): LiveData<List<EpisodeEntity>> {
        val episodeResult = MutableLiveData<List<EpisodeEntity>>()
        remoteDataSource.getEpisodes(tvShowId, object : RemoteDataSource.LoadEpisodesCallback {
            override fun onAllEpisodesReceived(episodeResponse: List<EpisodeResponse>) {
                val episodeList = ArrayList<EpisodeEntity>()
                for (response in episodeResponse){
                    val episode = EpisodeEntity(
                        response.episodeId,
                        response.tvShowId,
                        response.title,
                        response.duration
                    )
                    episodeList.add(episode)
                }
                episodeResult.postValue(episodeList)
            }
        })
        return episodeResult
    }
}