package com.example.moviecatalogue.data.source.local.entity

data class TvShowEntity(
        var tvShowId: String,
        var title: String,
        var year: Int,
        var rating: Float,
        var eps: Int,
        var genre: String,
        var sinopsis: String,
        var poster: String
)
