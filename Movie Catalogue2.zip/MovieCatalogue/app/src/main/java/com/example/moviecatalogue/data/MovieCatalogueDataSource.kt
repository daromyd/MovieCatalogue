package com.example.moviecatalogue.data

import androidx.lifecycle.LiveData
import com.example.moviecatalogue.data.source.local.entity.EpisodeEntity
import com.example.moviecatalogue.data.source.local.entity.MovieEntity
import com.example.moviecatalogue.data.source.local.entity.TvShowEntity

interface MovieCatalogueDataSource {
    fun getAllMovies(): LiveData<List<MovieEntity>>

    fun getAllTvShows(): LiveData<List<TvShowEntity>>

    fun getDetailMovie(movieId: String): LiveData<MovieEntity>

    fun getDetailTvShow(tvShowId: String) : LiveData<TvShowEntity>

    fun getEpisodesByTvShow(tvShowId: String): LiveData<List<EpisodeEntity>>
}