package com.example.moviecatalogue.data.source.local.entity

data class EpisodeEntity(
        var episodeId: String,
        var tvShowId: String,
        var title: String,
        var duration: Int
)
