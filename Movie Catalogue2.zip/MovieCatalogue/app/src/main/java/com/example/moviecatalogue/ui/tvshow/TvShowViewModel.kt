package com.example.moviecatalogue.ui.tvshow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.data.MovieCatalogueRepository
import com.example.moviecatalogue.data.source.local.entity.TvShowEntity

class TvShowViewModel(private val movieCatalogueRepository: MovieCatalogueRepository) : ViewModel(){

    fun getTvShow(): LiveData<List<TvShowEntity>> = movieCatalogueRepository.getAllTvShows()
}