package com.example.moviecatalogue.ui.detail.tvshow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.data.MovieCatalogueRepository
import com.example.moviecatalogue.data.source.local.entity.EpisodeEntity
import com.example.moviecatalogue.data.source.local.entity.TvShowEntity

class DetailTvShowViewModel(private val movieCatalogueRepository: MovieCatalogueRepository) : ViewModel(){
    private lateinit var tvShowId: String

    fun selectedTvShow(tvShowId: String){
        this.tvShowId = tvShowId
    }

    fun getTvShow(): LiveData<TvShowEntity> = movieCatalogueRepository.getDetailTvShow(tvShowId)


    fun getEpisode(): LiveData<List<EpisodeEntity>> = movieCatalogueRepository.getEpisodesByTvShow(tvShowId)
}